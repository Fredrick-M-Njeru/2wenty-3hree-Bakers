// var jina = prompt("Whats your Name");
// console.log(jina);
// var firstName = "Kelvin";
// var num = "45";

// keyword: typeof console.log(typeof firstName);
// console.log(typeof num);

// var number = 100;
// var marks = 96.4;
// var Num = 96.0;
// console.log(typeof number);
// console.log(typeof marks);
// console.log(typeof Num);

// var learning = true;
// var completed = false;

// var x = 20 > 10;
// console.log(x);
// console.log(typeof learning);
// console.log(completed);

// var y = null;
// console.log(y);

// var z;
// console.log(z);

// let pets = ["Dogs", "Cats", "cows", "sheep"];
// console.log(pets.length);
// console.log(pets);

// Manipulate
// accessing the values in the array
// bracket notation []
// . notation objects
// console.log(pets[0]);

// methods in arrays
// keyword
// length- highlights to you the number of values in your Array

// var a = 8;
// var b = 10;

// Interchange the values of the variables:
// Rules; Redclare
//        Do not change the code.
//        solve use only three lines of code
//        log your result a = 10, b = 8
// Array methods [shift unshift slice pop push forEach]

// var array = [1, 2, 3, 4, 5, 6, 7];
// var courses = ["soft dev", "JS", "Html", "css"];
// console.log(array.length);
// console.log(courses.push("Python"));
// console.log(courses.pop());
// console.log(courses.shift());
// console.log(courses.unshift("Node js"));
// console.log(courses);

// Functions
// function Example(name) {
//   alert(name);
// }
// Example("Kelvin");

// callback functions
function myDisplay(name) {
  return name;
}

function First(x, y) {
  console.log(x);
}

First(myDisplay("Ubunifu"));

// return
// Anonymous function
var z = function () {};
